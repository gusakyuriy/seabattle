var LevelInfo = [
	{
		camera:{
			scale:0.30, // // min = 0.25
		},
		players:{
			x: 1200,	
		},
		wind:[0.2, 0.7],
	}
];