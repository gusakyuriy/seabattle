var GunInfo = [
	{
		textureName	: "gun_0",
		speedStart	: 60,
		mass		: 10,
		damage		: 5,
	},	
	
];