var ShipInfo = [
	{
		textureName	: "ship_0",
		life		: 5,
		nCrash		: 12,
		nSmoke		: 15,
		rect		: [
			{x:-220, y:-90, width:380, height:100},
			{x:-100, y:-300, width:80, height:300}
		]
	},	
	
];

